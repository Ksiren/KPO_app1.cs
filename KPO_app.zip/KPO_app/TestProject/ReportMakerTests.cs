﻿//using KPO_app;
//using Moq;
//using System.IO;
//using System.Security.Cryptography.X509Certificates;
//using Xunit;

//namespace KPO_appTests
//{
//    public class ReportMakerTests
//    {
//        Mock<Zoo> zoo;
//        ReportMaker reportMaker;
//        StringWriter stringWriter;
//        public ReportMakerTests()
//        {
//            zoo = new Mock<Zoo>(Mock.Of<IHealthCheck>());
//            reportMaker = new ReportMaker(zoo.Object);
//            stringWriter = new StringWriter();
//        }

//        [Fact]
//        public void PrintListOfContact_WriteAnimalsWithKindness()
//        {
//            var contactAnimals = new List<Animal> { new Rabbit(8), new Monkey(7) };
//            zoo.Setup(z => z.ListOfContAnimals()).Returns(contactAnimals);

//            reportMaker.PrintListOfContact();
//            var output = stringWriter.ToString();

//            Assert.Contains("List of contact animals:", output);
//            Assert.Contains("Rabbit, kindness - 8", output);
//            Assert.Contains("Monkey, kindness - 7", output);
//        }

//        [Fact]
//        public void PrintListOfThings_WriteThingsWithNumbers()
//        {
//            var things = new List<Thing> { new Table { Number = 1 }, new Computer { Number = 2 }};
//            zoo.Setup(z => z.things).Returns(things);

//            var output = stringWriter.ToString();

//            Assert.Contains("List of things:", output);
//            Assert.Contains("(1) Table", output);
//            Assert.Contains("(2) Computer", output);
//        }

//        [Fact]
//        public void PrintListOfAnimals_WritesAllAnimals()
//        {
//            var animals = new List<Animal> { new Tiger(), new Rabbit(5), new Wolf() };
//            zoo.Setup(z => z.animals).Returns(animals);
//            stringWriter.GetStringBuilder().Clear();

//            reportMaker.PrintListOfAnimals();
//            var output = stringWriter.ToString();

//            Assert.Contains("List of animals:", output);
//            Assert.Contains("Tiger", output);
//            Assert.Contains("Rabbit", output);
//            Assert.Contains("Wolf", output);
//        }

//        [Fact]
//        public void PrintWholeReport_IsCorrect()
//        {
//            zoo.Setup(z => z.NumOfAnimals()).Returns(10);
//            zoo.Setup(z => z.NumOfFood()).Returns(15);
//            zoo.Setup(z => z.ListOfContAnimals()).Returns(new List<Animal>());
//            stringWriter.GetStringBuilder().Clear();

//            reportMaker.PrintWholeReport();
//            var printed = stringWriter.ToString();

//            Assert.Contains("Report about happening in zoo:", printed);
//            Assert.Contains("Total Animals: 10", printed);
//            Assert.Contains("Total kg Food per day: 15", printed);
//            Assert.Contains("List of contact animals:", printed);
//            Assert.Contains("List of animals:", printed);
//            Assert.Contains("List of things:", printed);
//        }
//    }
//}
