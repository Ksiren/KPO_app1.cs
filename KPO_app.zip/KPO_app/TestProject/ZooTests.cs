﻿using KPO_app;
using Xunit;
using Moq;

namespace KPO_appTests
{
    public class ZooTests
    {
        Mock<IHealthCheck> mockHealthCheck;
        Zoo zoo;
        public ZooTests()
        {
            mockHealthCheck = new Mock<IHealthCheck>();
            zoo = new Zoo(mockHealthCheck.Object);
        }

        [Fact]
        public void Construct_Correct()
        {
            var _mockHealthCheck = new Mock<IHealthCheck>();

            var _zoo = new Zoo(_mockHealthCheck.Object);

            Assert.NotNull(_zoo);
            Assert.Empty(_zoo.animals);
            Assert.Empty(_zoo.things);
        }

        [Fact]
        public void AddAnimal_WhenAnimalHealth_Correct()
        {
            var animal = new Rabbit(5);
            mockHealthCheck.Setup(h => h.IsHealthyCheck(animal)).Returns(true);

            var answer = zoo.AddAnimal(animal);

            Assert.True(answer);
            Assert.Contains(animal, zoo.animals);
        }

        [Fact]
        public void DoNotAddAnimal_WhenAnimalSick_Correct()
        {
            var animal = new Rabbit(5);
            mockHealthCheck.Setup(h => h.IsHealthyCheck(animal)).Returns(false);

            var answer = zoo.AddAnimal(animal);

            Assert.False(answer);
            Assert.Empty(zoo.animals);
        }

        [Fact]
        public void AddingThing_AndItsNumber_Correct()
        {
            var thing = new Mock<Thing>();

            zoo.AddThing(thing.Object);

            Assert.Equal(1, thing.Object.Number);
            Assert.Contains(thing.Object, zoo.things);
        }

        [Fact]
        public void NumOfAnimals_ReturnCorrectNumber()
        {
            mockHealthCheck.Setup(h => h.IsHealthyCheck(It.IsAny<Animal>())).Returns(true);
            zoo.AddAnimal(new Mock<Animal>().Object);
            zoo.AddAnimal(new Mock<Animal>().Object);
            zoo.AddAnimal(new Mock<Animal>().Object);

            var answer = zoo.NumOfAnimals();

            Assert.Equal(3, answer);
        }

        [Fact]
        public void NumOfFood_ReturnCorrectNum()
        {
            mockHealthCheck.Setup(h => h.IsHealthyCheck(It.IsAny<Animal>())).Returns(true);
            zoo.AddAnimal(new Rabbit(5));
            zoo.AddAnimal(new Monkey(5));
            zoo.AddAnimal(new Tiger());
            zoo.AddAnimal(new Wolf());

            var answer = zoo.NumOfFood();

            Assert.Equal(3+1+9+5, answer);

        }

        [Fact]
        public void ListOfContAnimals_ReturnOnlyKindHerbs()
        {
            mockHealthCheck.Setup(h => h.IsHealthyCheck(It.IsAny<Animal>())).Returns(true);
            var goodR = new Rabbit(10);
            var goodM = new Monkey(6);
            var evilM = new Monkey(5);
            var tiger = new Tiger();
            zoo.AddAnimal(goodR);
            zoo.AddAnimal(goodM);
            zoo.AddAnimal(evilM);
            zoo.AddAnimal(tiger);

            var answer = zoo.ListOfContAnimals();

            Assert.Equal(2, answer.Count);
            Assert.Contains(goodR, answer);
            Assert.Contains(goodM, answer);
            Assert.DoesNotContain(evilM, answer);
            Assert.DoesNotContain(tiger, answer);
        }

    }
}
