using KPO_app;
using Xunit;
using Moq;

namespace KPO_appTests
{
    public class VetClinicTests
    {
        VetClinic vetClinic;
        public VetClinicTests()
        {
            vetClinic = new VetClinic();
        }

        [Fact]
        public void IsHealthyCheck_ReturnsCorrect()
        {
            var animal = new Mock<Animal>();

            var answer = vetClinic.IsHealthyCheck(animal.Object);

            Assert.Equal(answer, animal.Object.IsHealthy);
            Assert.IsType<bool>(answer);
        }

    }
}